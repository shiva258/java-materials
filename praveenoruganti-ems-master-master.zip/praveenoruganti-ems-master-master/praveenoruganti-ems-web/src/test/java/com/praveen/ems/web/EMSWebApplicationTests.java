package com.praveen.ems.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EMSWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
