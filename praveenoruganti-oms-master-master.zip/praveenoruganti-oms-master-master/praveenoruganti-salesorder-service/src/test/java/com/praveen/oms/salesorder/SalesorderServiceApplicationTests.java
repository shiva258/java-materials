package com.praveen.oms.salesorder;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesorderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
